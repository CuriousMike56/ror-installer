Mods used in loading backgrounds:

loading_01:
Terrain:
 https://forum.rigsofrods.org/resources/ladoga.160/
Vehicle: 
https://forum.rigsofrods.org/resources/1988-audi-ur-quattro.85/

loading_02:
Terrain: 
https://forum.rigsofrods.org/resources/brutal-valley.168/
Vehicle: 
https://forum.rigsofrods.org/resources/1983-1984-toyota-hilux-and-4runner.234/

loading_03:
Terrain: 
https://forum.rigsofrods.org/resources/lapaz.398/
Vehicles:
https://forum.rigsofrods.org/resources/bobcat-s770-cat-262d-komatsu-sk820-5-takeuchi-tl12v2-deere-332g.596/
http://archives.rigsofrods.net/repo/files/repofiles-1st-batch/119b7db37788e1e3f9ca27598c41014b7bc6658b_TrafficCone.zip

loading_04:
Terrain:
https://forum.rigsofrods.org/resources/greece.18/
Vehicles:
https://forum.rigsofrods.org/resources/volvo-fmx-8x6-with-effer-1355.650/
https://forum.rigsofrods.org/resources/assorted-cement-pipes.651/

loading_05:
Terrain:
https://forum.rigsofrods.org/resources/badlands-rally.157/
Vehicle:
https://forum.rigsofrods.org/resources/komatsu-gd655.415/

loading_06:
Terrain:
https://forum.rigsofrods.org/resources/badlands-rally.157/
Vehicle:
https://forum.rigsofrods.org/resources/sisu-sa-150-240.316/

loading_07:
Terrain:
https://forum.rigsofrods.org/resources/auriga-proving-grounds.141/
Vehicles:
https://forum.rigsofrods.org/resources/low-cab-forward-trucks.423/
https://forum.rigsofrods.org/resources/bobcat-s770-cat-262d-komatsu-sk820-5-takeuchi-tl12v2-deere-332g.596/
https://forum.rigsofrods.org/resources/various-skid-loads.413/

loading_08:
Terrain:
https://forum.rigsofrods.org/resources/greece.18/
Vehicles:
https://forum.rigsofrods.org/resources/volvo-fmx-8x6-with-effer-1355.650/
https://forum.rigsofrods.org/resources/assorted-cement-pipes.651/

loading_09:
Terrain:
https://forum.rigsofrods.org/resources/rally-desert-australia-style.138/
Vehicle:
https://forum.rigsofrods.org/resources/unlimited-class-trophy-truck.89/

loading_10:
Terrain:
https://forum.rigsofrods.org/resources/fall-run.149/
Vehicles:
https://forum.rigsofrods.org/resources/komatsu-hm400.414/
https://forum.rigsofrods.org/resources/komatsu-pc450lc-8.417/
https://forum.rigsofrods.org/resources/rock-pack.126/

loading_11:
Terrain:
https://forum.rigsofrods.org/resources/windmill-mountain.500/
Vehicles:
https://forum.rigsofrods.org/resources/bombardier-alp-45dp.170/
https://forum.rigsofrods.org/resources/flatcar.175/
https://forum.rigsofrods.org/resources/hughes-500d.196/
https://forum.rigsofrods.org/resources/wooden-crate-pack.652/

loading_12:
Terrain:
https://forum.rigsofrods.org/resources/mry11.603/
Vehicle:
https://forum.rigsofrods.org/resources/1996-dodge-viper-gts-coupe.88/

loading_13:
Terrain:
https://forum.rigsofrods.org/resources/brutal-valley.168/
Vehicle:
https://forum.rigsofrods.org/resources/desperado-rock-bouncer-buggy.166/

loading_14:
Terrain:
 https://forum.rigsofrods.org/resources/ladoga.160/
Vehicle:
https://forum.rigsofrods.org/resources/max-iv-6x6.334/

loading_15:
Terrain:
https://forum.rigsofrods.org/resources/reflection-room.31/
Vehicle:
https://forum.rigsofrods.org/resources/grave-digger-35.648/

loading_16:
Terrain:
https://forum.rigsofrods.org/resources/brutal-valley.168/
Vehicles:
https://forum.rigsofrods.org/resources/desperado-rock-bouncer-buggy.166/
https://forum.rigsofrods.org/resources/2014-ford-f-250-super-duty-xlt.97/
https://forum.rigsofrods.org/resources/1990-bigtex-16.429/

loading_17:
Terrain:
https://forum.rigsofrods.org/resources/auriga-proving-grounds.141/
Vehicles:
https://forum.rigsofrods.org/resources/freightliner-fla-cabover-semi.601/
https://forum.rigsofrods.org/resources/b-double-flatbed-trailers.222/

loading_18:
Terrain:
https://forum.rigsofrods.org/resources/bajarama-v2.131/
Vehicle:
https://forum.rigsofrods.org/resources/unlimited-class-trophy-truck.89/

loading_19:
Terrain:
https://forum.rigsofrods.org/resources/taiga.582/
Vehicles:
https://forum.rigsofrods.org/resources/sisu-sa-150-240.316/
https://forum.rigsofrods.org/resources/piper-j3-super-cub.164/
https://forum.rigsofrods.org/resources/tjs-suzuki-samurai-crawler.436/
https://forum.rigsofrods.org/resources/gypsea-12-jon-boat.193/

loading_20:
Terrain:
https://forum.rigsofrods.org/resources/badlands-rally.157/
Vehicles:
https://forum.rigsofrods.org/resources/1984-kenworth-sar.306/
https://forum.rigsofrods.org/resources/oil-road-train.653/

loading_21:
Terrain:
https://forum.rigsofrods.org/resources/russian-mud-course.219/
Vehicle:
https://forum.rigsofrods.org/resources/tatra-t813-dakar.145/

loading_22:
Terrain:
https://forum.rigsofrods.org/resources/rally-desert-australia-style.138/
Vehicle:
https://forum.rigsofrods.org/resources/1951-chevy-3100-street-rod.235/

loading_23:
Terrain:
https://forum.rigsofrods.org/resources/utah-desert-hills.512/
Vehicle:
https://forum.rigsofrods.org/resources/wahoo-boat-v2-with-trailer.205/
